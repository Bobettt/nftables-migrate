# Fedora handoff: first real kernel correctness checks

This directory is self-contained. It contains no raw MAWI capture. `traffic_100k.pcap` is an unchanged copy of the audited MAWI_MATCHED_DOMAIN seed-42 PCAP. Use the SAME file for all variants. `correctness_traffic.pcap` is a separate 24-packet functional fixture, not a MAWI benchmark distribution.

PCAP files are deliberately Git-ignored. Copy this prepared directory itself to Fedora; a source-only Git checkout will not include the two PCAPs. The Windows `prepare_linux_handoff.ps1` rebuilds this bundle from the existing local audited artifacts without processing raw MAWI captures.

Nothing here has been executed in a Linux kernel yet. Java structural tests and Windows TShark decoding do not establish nft syntax, kernel equivalence, packet delivery or performance.

Target: one Fedora x86_64 VM, about 4 vCPU / 8 GB RAM / 80 GB disk. All links/namespaces are inside the guest. No extra VMs are needed. Run commands from this directory after copying it to Fedora.

## Dependencies and integrity

```bash
sudo dnf install -y nftables iproute tcpdump tcpreplay wireshark-cli procps-ng coreutils diffutils
chmod +x linux-testbed/*.sh
sha256sum -c SHA256SUMS.txt
uname -r
nft --version
tcpreplay --version
```

Fedora package names: [nftables](https://packages.fedoraproject.org/pkgs/nftables/nftables/), [iproute](https://packages.fedoraproject.org/pkgs/iproute/iproute/), [tcpreplay](https://packages.fedoraproject.org/pkgs/tcpreplay/tcpreplay/), [wireshark-cli](https://packages.fedoraproject.org/pkgs/wireshark/wireshark-cli/). Java is not needed to replay these prepared artifacts.

## Topology and smoke test

```bash
sudo env TESTBED_MTU=65535 ./linux-testbed/setup.sh
sudo env TESTBED_MTU=65535 ./linux-testbed/smoke-test.sh correctness_traffic.pcap
```

Topology: `pet-sender -> pet-firewall -> pet-receiver`, using veth and `hook forward`. The smoke script recreates this topology. Inspect its receiver counts: accept-all must receive 24, drop-all must receive 0. A completed script alone is not a PASS; capture loss or missing packets must be investigated.

The small fixture requires IP MTU 1,986; the final PCAP requires 23,220. The setup sets all veth MTUs to 65,535. Replay checks `TESTBED_MTU` before sending and fails clearly if the input requires more. Keep the same MTU environment for setup/replay. Optional negative preflight (expected nonzero exit, no replay):

```bash
sudo env TESTBED_MTU=1500 ./linux-testbed/replay.sh traffic_100k.pcap trace
```

## Syntax checks, isolated from the guest's main firewall

Flush ONLY the experiment firewall namespace before checking these complete files:

```bash
sudo ip netns exec pet-firewall nft flush ruleset
sudo ip netns exec pet-firewall nft -c -f baseline_forward.nft
sudo ip netns exec pet-firewall nft -c -f reordered_forward.nft
sudo ip netns exec pet-firewall nft -c -f specialized_forward.nft
```

Do not run the complete example in the guest's main namespace. All three variants declare `ip filter`; loading one over an already loaded variant can duplicate rules. The supplied loader flushes only `pet-firewall` before each load.

## Real load and replay

The wrapper runs the real `nft -c -f` and `nft -f` inside `pet-firewall`:

```bash
sudo ./linux-testbed/load-ruleset.sh baseline_forward.nft
sudo env TESTBED_MTU=65535 ./linux-testbed/replay.sh correctness_traffic.pcap trace
```

Equivalent explicit load (if needed for debugging):

```bash
sudo ip netns exec pet-firewall nft flush ruleset
sudo ip netns exec pet-firewall nft -f baseline_forward.nft
sudo ip netns exec pet-firewall nft list ruleset
```

## Baseline vs reordered, then baseline vs specialized

```bash
sudo env TESTBED_MTU=65535 ./linux-testbed/correctness-run.sh correctness_traffic.pcap baseline_forward.nft reordered_forward.nft
sudo env TESTBED_MTU=65535 ./linux-testbed/correctness-run.sh correctness_traffic.pcap baseline_forward.nft specialized_forward.nft
```

Check each new directory under `linux-testbed/results/correctness_*`: status, packet diff, receiver captures and counters. The small fixture has 19 expected accepted frames and 5 drops; see `correctness_cases.md`. An empty-vs-empty packet diff is not sufficient evidence. Missing captures, tcpdump drops or tcpreplay errors invalidate the run.

Then repeat with the exact same final PCAP for both sides:

```bash
sudo env TESTBED_MTU=65535 ./linux-testbed/correctness-run.sh traffic_100k.pcap baseline_forward.nft reordered_forward.nft
sudo env TESTBED_MTU=65535 ./linux-testbed/correctness-run.sh traffic_100k.pcap baseline_forward.nft specialized_forward.nft
```

`trace` preserves the prepared timing but may still be fast. These results remain capture-dependent. The current comparison uses packet header tuples/IP IDs, not full payload equivalence; combine it with the small fixture, counters and inspection of nft's compiled rules. Fragment/malformed-packet edge cases and raw transport-load behavior should be checked on the installed kernel before extending the scientific claim beyond this unfragmented prepared workload.

## What the coverage report means

`coverage.txt` evaluates supported baseline predicates only, skipping LOG. Its local region is original IDs 1-6 (the two specialized regions); moved IDs are 2,3,4. Because rule 10 is a fallback ACCEPT, any-predicate coverage is trivially 100%; this is not evidence of speed or useful selectivity. `specialization.txt` maps baseline IDs into E. E's dispatch/child chains are NOT falsely evaluated by CoverageAnalyzer.

## Later A/B/C/D/E/F layout (not run yet)

| Variant | Transformation |
|---|---|
| A | baseline_forward.nft |
| B | A + stock nft --optimize |
| C | reordered_forward.nft |
| D | C + stock nft --optimize |
| E | specialized_forward.nft |
| F | E + stock nft --optimize |

Only after correctness succeeds, create B/D/F on Fedora by loading with the installed stock optimizer and saving the actual kernel ruleset. Do not treat optimizer diagnostics as a loadable nft file:

```bash
sudo ip netns exec pet-firewall nft flush ruleset
sudo ip netns exec pet-firewall nft --optimize -f baseline_forward.nft
sudo ip netns exec pet-firewall nft -s list ruleset > baseline_stock.nft
sudo ip netns exec pet-firewall nft flush ruleset
sudo ip netns exec pet-firewall nft --optimize -f reordered_forward.nft
sudo ip netns exec pet-firewall nft -s list ruleset > reordered_stock.nft
sudo ip netns exec pet-firewall nft flush ruleset
sudo ip netns exec pet-firewall nft --optimize -f specialized_forward.nft
sudo ip netns exec pet-firewall nft -s list ruleset > specialized_stock.nft
```

Stock optimization and jump/raw-payload semantics are documented in the [official nft manual](https://netfilter.org/projects/nftables/manpage.html). B/D/F are Linux-only artifacts and must each pass the same correctness checks. They are not inputs to the limited Java parser. No performance improvement is claimed, and no performance benchmark was started during Windows preparation.
