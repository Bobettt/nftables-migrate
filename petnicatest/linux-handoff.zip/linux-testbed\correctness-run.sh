#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd tcpdump; require_cmd tshark
[[ $# -eq 3 ]] || { echo "Usage: $0 traffic.pcap baseline.nft optimized.nft" >&2;exit 2; }
pcap=$(abs "$1"); base=$(abs "$2"); opt=$(abs "$3"); out="$(dirname "$0")/results/correctness_$(date +%Y%m%d_%H%M%S)"; mkdir -p "$out"
for item in baseline optimized;do
  if [[ $item == baseline ]];then rules=$base;else rules=$opt;fi
  "$(dirname "$0")/load-ruleset.sh" "$rules" > "$out/${item}_rules.txt"
  ip netns exec "$RECEIVER_NS" tcpdump -U -n -i "$RECEIVER_IF" -w "$out/${item}.pcap" ip >/dev/null 2>&1 & cap=$!; sleep 1
  "$(dirname "$0")/replay.sh" "$pcap" trace > "$out/${item}_replay.txt"; sleep 1; kill -INT "$cap" 2>/dev/null || true; wait "$cap" 2>/dev/null || true
  tshark -n -r "$out/${item}.pcap" -T fields -E separator=, -e ip.id -e ip.src -e ip.dst -e ip.proto -e tcp.srcport -e udp.srcport -e tcp.dstport -e udp.dstport -e ip.len > "$out/${item}_packets.txt"; ip netns exec "$FIREWALL_NS" nft list ruleset > "$out/${item}_counters.txt"
done
if diff -u "$out/baseline_packets.txt" "$out/optimized_packets.txt" > "$out/packet_diff.txt";then status=PASS;else status=DIFFERENT;fi
echo "$status" | tee "$out/status.txt"
