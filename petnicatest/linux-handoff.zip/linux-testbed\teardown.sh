#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root
for ns in "$SENDER_NS" "$FIREWALL_NS" "$RECEIVER_NS"; do ip netns pids "$ns" 2>/dev/null | xargs -r kill 2>/dev/null || true; ip netns del "$ns" 2>/dev/null || true; done
