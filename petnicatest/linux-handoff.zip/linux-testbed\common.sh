#!/usr/bin/env bash
set -euo pipefail
SENDER_NS=${SENDER_NS:-pet-sender}; FIREWALL_NS=${FIREWALL_NS:-pet-firewall}; RECEIVER_NS=${RECEIVER_NS:-pet-receiver}
TESTBED_MTU=${TESTBED_MTU:-65535}
SENDER_IF=veth-s; FW_LEFT=fw-left; FW_RIGHT=fw-right; RECEIVER_IF=veth-r
require_root(){ [[ ${EUID} -eq 0 ]] || { echo "Run as root" >&2; exit 1; }; }
require_cmd(){ command -v "$1" >/dev/null || { echo "Missing command: $1" >&2; exit 1; }; }
abs(){ readlink -f "$1"; }
