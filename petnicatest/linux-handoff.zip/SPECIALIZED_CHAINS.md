# Protocol specialization MVP

Pipeline: translated baseline A -> unchanged SafeReorderOptimizer -> C -> separate SpecializedChainOptimizer -> E.
The default CLI still produces C. Opt in with `--specialize`; default minimum region size is 3, configurable to any integer >= 2.

```powershell
java OptimizerMain outputs\specialized-example\baseline_forward.nft outputs\specialized-example\reordered_forward.nft --chain FORWARD
java OptimizerMain outputs\specialized-example\baseline_forward.nft outputs\specialized-example\specialized_forward.nft --chain FORWARD --specialize --specialization-report outputs\specialized-example\specialization.txt
```

## Exact eligibility

A region is a maximal physically consecutive run of selected-chain rule lines, all supported by the existing NftParser, all requiring exactly the same TCP or UDP protocol, and all ending in ACCEPT or DROP. All predicates must precede any counter statement. No additional reordering is performed. A comment, unrelated line/chain, unsupported rule, LOG, MARK read/write, jump/goto/return or protocol change ends the run. All MARK participants are excluded, which also excludes RAW/WAR/WAW cases. ANY and ICMP are never specialized.

The complete file must use the project's translated `add table/chain/rule` form, with one target `ip filter` table declaration and one selected INPUT/FORWARD base-chain declaration (numeric priority, accept/drop policy). Unknown lifecycle commands or unproven file context cause a no-op. This is intentionally not a general nftables parser. Untransformed/no-op files are copied byte-for-byte; transformed files retain all unrelated line contents, subject to the existing line-ending convention.

## Continuation argument

For a contiguous region `(protocol=P and Q1 -> V1), ..., (protocol=P and Qn -> Vn)`, replace it with a guarded `jump` to a fresh regular chain containing `Q1 -> V1, ..., Qn -> Vn` in the same order.

- A packet not having P fails the dispatch and reaches the same next parent rule as before. Every original region rule also failed before any counter/effect.
- A packet having P enters with explicit `KnownProtocol(P)` metadata. The child checks exactly the remaining predicates, in their original order, with the original counters and terminal verdicts.
- ACCEPT/DROP in the child retain their terminal semantics. If no child rule matches, the regular chain ends and returns to the rule after the dispatch, which is precisely the original region continuation.
- No interposed rule can be skipped because regions contain consecutive physical rule slots only. No pre-predicate counter, state update, LOG or control-flow statement can participate.

This proof relies on nftables jump/regular-chain semantics, not on a Java firewall evaluator. The new tests inspect emitted structure and proof prerequisites. Actual kernel correctness remains a Linux validation task.

## Lowering and metadata

`KnownProtocol` is an explicit TCP/UDP-only type. The emitter checks that it agrees with Rule IR before lowering. It removes explicit `ip protocol P` and replaces typed port loads with the same raw transport fields: source `@th,0,16`, destination `@th,16,16`. Numeric single/range values and address predicates are retained. This avoids reintroducing implicit protocol dependencies through `tcp/udp dport`. Generated chain names are quoted, deterministic, and checked for collisions.

The nftables manual documents both guarded raw transport loads (which add no implicit protocol dependency) and jump/implicit-return behavior: [official nft manual](https://netfilter.org/projects/nftables/manpage.html).

Metadata reports all eligible runs and rejected selected-rule singleton candidates, skip reasons, baseline rule IDs (when supplied by the pipeline), post-reorder positions, protocol, chain names and chain sizes. `redundant_protocol_predicates_removed` counts one semantic protocol constraint per specialized rule. Separate fields count explicit textual protocol expressions removed and typed port expressions lowered. These are structural counts, not measured instruction counts or performance improvements.

New child chains must only be entered through their emitted guard. Do not attach hooks or add unguarded external callers to them. Do not feed E back into the MVP parser as if its child rules were ordinary supported baseline rules. Coverage is measured on baseline predicates, with specialization metadata mapping their identities into E.

One new pipeline regression exposed an existing parser/IR mismatch: `counter ip protocol udp drop` was treated as a UDP-only predicate even though its counter executes before that test. Moving a disjoint TCP ACCEPT before it changes the counter. The regression failed with the audited parser. A narrow parser guard now preserves any rule with an observable statement before a later predicate as an unsupported barrier. LOG-before-predicate and MARK-write-before-predicate have matching regression cases. SafeReorderOptimizer itself is unchanged.

No MAWI calibration, generator distributions, Rule IR, SafeReorderOptimizer, dependency rules, coverage semantics or PCAP format were changed. The only parser change is the demonstrated conservative effect-order bug fix above.
