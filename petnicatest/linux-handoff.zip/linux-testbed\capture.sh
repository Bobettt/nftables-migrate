#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd tcpdump
[[ $# -eq 1 ]] || { echo "Usage: $0 receiver.pcap" >&2; exit 1; }; out=$(readlink -m "$1")
exec ip netns exec "$RECEIVER_NS" tcpdump -U -n -i "$RECEIVER_IF" -w "$out" ip
