#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd tcpreplay; require_cmd tshark
[[ $# -ge 1 && -f $1 ]] || { echo "Usage: $0 traffic.pcap [trace|topspeed|pps RATE]" >&2; exit 1; }; pcap=$(abs "$1"); mode=${2:-trace}
max_ip=$(tshark -n -r "$pcap" -T fields -e ip.len 2>/dev/null | sort -n | tail -1); [[ -n $max_ip ]] || { echo "No IPv4 packets in $pcap" >&2; exit 3; }; (( max_ip <= TESTBED_MTU )) || { echo "PCAP needs IPv4 MTU $max_ip, configured TESTBED_MTU=$TESTBED_MTU" >&2; exit 3; }
case "$mode" in trace) args=() ;; topspeed) args=(--topspeed) ;; pps) [[ $# -eq 3 ]] || exit 2; args=(--pps "$3") ;; *) echo "Unknown mode: $mode" >&2; exit 2;; esac
ip netns exec "$SENDER_NS" tcpreplay --intf1="$SENDER_IF" "${args[@]}" "$pcap"
