#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root
[[ $# -eq 1 && -f $1 ]] || { echo "Usage: $0 small-traffic.pcap" >&2;exit 2; }; pcap=$(abs "$1"); dir=$(dirname "$0")
"$dir/setup.sh"; "$dir/benchmark-run.sh" --pcap "$pcap" --rules "$dir/rules/accept-forward.nft" --label smoke_accept --repetitions 1 --mode trace
"$dir/benchmark-run.sh" --pcap "$pcap" --rules "$dir/rules/drop-forward.nft" --label smoke_drop --repetitions 1 --mode trace
echo "Inspect results: accept received count must equal input packet count; drop received count must be zero."
