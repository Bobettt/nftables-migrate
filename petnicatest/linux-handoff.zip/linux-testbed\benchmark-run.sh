#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd tcpdump; require_cmd sha256sum
pcap=; rules=; label=; reps=3; mode=topspeed; rate=
while [[ $# -gt 0 ]];do case "$1" in --pcap)pcap=$(abs "$2");shift 2;;--rules)rules=$(abs "$2");shift 2;;--label)label=$2;shift 2;;--repetitions)reps=$2;shift 2;;--mode)mode=$2;shift 2;;--rate)rate=$2;shift 2;;*)echo "Unknown argument: $1" >&2;exit 2;;esac;done
[[ -f $pcap && -f $rules && -n $label ]] || { echo "Required: --pcap FILE --rules FILE --label NAME" >&2;exit 2; }
root="$(dirname "$0")/results/$(basename "$pcap" .pcap)/$label"; mkdir -p "$root"; summary="$root/summary.csv"; input_packets=$(tcpdump -nr "$pcap" 2>/dev/null|wc -l)
echo 'repetition,timestamp,hostname,kernel,nft_version,pcap_sha256,rules_sha256,packets_sent,replay_mode,replay_rate,elapsed_seconds,packets_received,packets_dropped,cpu_metrics,notes' > "$summary"
for ((i=1;i<=reps;i++));do
  "$(dirname "$0")/load-ruleset.sh" "$rules" > "$root/rules_run$i.txt"
  capture="$root/receiver_run$i.pcap"; ip netns exec "$RECEIVER_NS" tcpdump -U -n -i "$RECEIVER_IF" -w "$capture" ip >/dev/null 2>&1 & cap=$!; sleep 1
  start=$(date +%s.%N); if [[ $mode == pps ]];then "$(dirname "$0")/replay.sh" "$pcap" pps "$rate" > "$root/replay_run$i.txt";else "$(dirname "$0")/replay.sh" "$pcap" "$mode" > "$root/replay_run$i.txt";fi; end=$(date +%s.%N)
  sleep 1; kill -INT "$cap" 2>/dev/null || true; wait "$cap" 2>/dev/null || true
  received=$(tcpdump -nr "$capture" ip 2>/dev/null|wc -l); elapsed=$(awk -v a="$start" -v b="$end" 'BEGIN{printf "%.6f",b-a}')
  dropped=$((input_packets-received)); echo "$i,$(date -Iseconds),$(hostname),$(uname -r),$(nft --version|tr ',' ';'),$(sha256sum "$pcap"|cut -d' ' -f1),$(sha256sum "$rules"|cut -d' ' -f1),$input_packets,$mode,${rate:-NA},$elapsed,$received,$dropped,not_collected,tracing_off" >> "$summary"
  ip netns exec "$FIREWALL_NS" nft list ruleset > "$root/counters_run$i.txt"
done
echo "$summary"
