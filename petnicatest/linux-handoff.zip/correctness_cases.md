# Small correctness fixture

24 frames, 12 two-direction flows, deterministic IDs/timestamps and synthetic payload. This is a functional fixture, not a traffic calibration sample. The packet writer stores event_id modulo 65536 in IPv4 ID; all IDs here are unique. Expected behavior below is derived manually from this ten-rule example, not from a Java firewall simulator.

| Forward event ID | Input case | Expected forward verdict | Reverse event ID/verdict |
|---:|---|---|---|
| 0 | TCP/443, first source range | ACCEPT in TCP region | 1 ACCEPT at fallback |
| 2 | TCP/443, second source range | ACCEPT in TCP region | 3 ACCEPT at fallback |
| 4 | TCP/443, third source range, 2000-byte frame | ACCEPT in TCP region | 5 ACCEPT at fallback |
| 6 | TCP/443, source outside all three ranges | miss child; LOG; fallback ACCEPT | 7 ACCEPT at fallback |
| 8 | TCP/80 | miss child; LOG; continuation DROP | 9 ACCEPT at fallback |
| 10 | UDP/53 | DROP in UDP region | 11 ACCEPT at fallback |
| 12 | UDP/123 | DROP in UDP region | 13 ACCEPT at fallback |
| 14 | UDP/161 | ACCEPT in UDP region | 15 ACCEPT at fallback |
| 16 | UDP/9999 | miss child; fallback ACCEPT | 17 ACCEPT at fallback |
| 18 | ICMP | protocol dispatches both fail; DROP | 19 DROP |
| 20 | TCP/8080 | miss child; LOG; fallback ACCEPT | 21 ACCEPT at fallback |
| 22 | UDP/0 | miss child; fallback ACCEPT | 23 ACCEPT at fallback |

Expected dropped IPv4 IDs: 8,10,12,18,19. All other 19 frames should reach the receiver in A, C and E. LOG behavior/counters should also be inspected; packet acceptance equality alone does not establish equality of all observable effects. With accept-all smoke rules expect all 24; with drop-all smoke rules expect zero.
