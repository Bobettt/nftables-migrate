#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd ip
"$(dirname "$0")/teardown.sh" >/dev/null 2>&1 || true
ip netns add "$SENDER_NS"; ip netns add "$FIREWALL_NS"; ip netns add "$RECEIVER_NS"
ip link add "$SENDER_IF" type veth peer name "$FW_LEFT"; ip link add "$FW_RIGHT" type veth peer name "$RECEIVER_IF"
ip link set "$SENDER_IF" mtu "$TESTBED_MTU"; ip link set "$FW_LEFT" mtu "$TESTBED_MTU"; ip link set "$FW_RIGHT" mtu "$TESTBED_MTU"; ip link set "$RECEIVER_IF" mtu "$TESTBED_MTU"
ip link set "$SENDER_IF" netns "$SENDER_NS"; ip link set "$FW_LEFT" netns "$FIREWALL_NS"; ip link set "$FW_RIGHT" netns "$FIREWALL_NS"; ip link set "$RECEIVER_IF" netns "$RECEIVER_NS"
ip -n "$SENDER_NS" link set lo up; ip -n "$FIREWALL_NS" link set lo up; ip -n "$RECEIVER_NS" link set lo up
ip -n "$SENDER_NS" link set "$SENDER_IF" address 02:00:00:00:00:02; ip -n "$FIREWALL_NS" link set "$FW_LEFT" address 02:00:00:00:00:01
ip -n "$FIREWALL_NS" link set "$FW_RIGHT" address 02:00:00:00:01:01; ip -n "$RECEIVER_NS" link set "$RECEIVER_IF" address 02:00:00:00:01:02
ip -n "$SENDER_NS" addr add 10.200.0.2/24 dev "$SENDER_IF"; ip -n "$FIREWALL_NS" addr add 10.200.0.1/24 dev "$FW_LEFT"
ip -n "$FIREWALL_NS" addr add 10.201.0.1/24 dev "$FW_RIGHT"; ip -n "$RECEIVER_NS" addr add 10.201.0.2/24 dev "$RECEIVER_IF"
ip -n "$SENDER_NS" link set "$SENDER_IF" up; ip -n "$FIREWALL_NS" link set "$FW_LEFT" up; ip -n "$FIREWALL_NS" link set "$FW_RIGHT" up; ip -n "$RECEIVER_NS" link set "$RECEIVER_IF" up
ip -n "$SENDER_NS" route add default via 10.200.0.1; ip -n "$FIREWALL_NS" route add default via 10.201.0.2
ip netns exec "$FIREWALL_NS" sysctl -qw net.ipv4.ip_forward=1
for ns in "$SENDER_NS" "$FIREWALL_NS" "$RECEIVER_NS"; do ip netns exec "$ns" sysctl -qw net.ipv4.conf.all.rp_filter=0; ip netns exec "$ns" sysctl -qw net.ipv4.conf.default.rp_filter=0; done
echo "Topology ready: $SENDER_NS -> $FIREWALL_NS -> $RECEIVER_NS (MTU $TESTBED_MTU)"
