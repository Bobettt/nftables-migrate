#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/common.sh"; require_root; require_cmd nft
[[ $# -eq 1 && -f $1 ]] || { echo "Usage: $0 ruleset.nft" >&2; exit 1; }; rules=$(abs "$1")
forward_hook='^[[:space:]]*((add[[:space:]]+chain[[:space:]]+[^[:space:]]+[[:space:]]+[^[:space:]]+[[:space:]]+[^[:space:]]+)|(chain[[:space:]]+[^[:space:]]+))[[:space:]]*\{[[:space:]]*type[[:space:]]+filter[[:space:]]+hook[[:space:]]+forward([[:space:];]|$)|^[[:space:]]*type[[:space:]]+filter[[:space:]]+hook[[:space:]]+forward([[:space:];]|$)'
grep -Eq "$forward_hook" "$rules" || { echo "Refusing ruleset without a forward hook: $rules" >&2; exit 3; }
ip netns exec "$FIREWALL_NS" nft flush ruleset; ip netns exec "$FIREWALL_NS" nft -c -f "$rules"; ip netns exec "$FIREWALL_NS" nft -f "$rules"; ip netns exec "$FIREWALL_NS" nft list ruleset
