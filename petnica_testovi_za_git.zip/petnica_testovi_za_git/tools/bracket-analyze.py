import csv
import random
import statistics as st
from collections import defaultdict

FILE = "bracket_benchmark.csv"
BOOTSTRAPS = 20000
RANDOM_SEED = 42

rounds = defaultdict(list)

with open(FILE, newline="") as f:
    for row in csv.DictReader(f):
        rounds[int(row["round"])].append({
            "position": int(row["position"]),
            "variant": row["variant"],
            "pps": float(row["pps"])
        })

normalized = defaultdict(list)
raw = defaultdict(list)
drifts = []
per_round = {}

for r in sorted(rounds):
    rows = rounds[r]
    a_rows = sorted([x for x in rows if x["variant"] == "A"], key=lambda x: x["position"])

    if len(a_rows) != 2:
        print(f"WARNING round {r}: expected 2 A measurements")
        continue

    a_pre = a_rows[0]["pps"]
    a_post = a_rows[1]["pps"]
    drift = 100.0 * (a_post / a_pre - 1.0)
    drifts.append(drift)
    per_round[r] = {}

    for x in rows:
        v = x["variant"]
        if v == "A":
            continue

        pos = x["position"]
        local_baseline = a_pre + (pos / 6.0) * (a_post - a_pre)
        ratio = x["pps"] / local_baseline
        improvement = 100.0 * (ratio - 1.0)

        normalized[v].append(improvement)
        raw[v].append(x["pps"])
        per_round[r][v] = ratio


def bootstrap_ci(values):
    rng = random.Random(RANDOM_SEED)
    n = len(values)
    means = []

    for _ in range(BOOTSTRAPS):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        means.append(st.mean(sample))

    means.sort()
    lo = means[int(0.025 * len(means))]
    hi = means[int(0.975 * len(means))]
    return lo, hi


print()
print("===== BASELINE DRIFT =====")
print(f"Rounds: {len(drifts)}")
print(f"Mean A_post/A_pre drift:   {st.mean(drifts):+.3f}%")
print(f"Median A_post/A_pre drift: {st.median(drifts):+.3f}%")
print(f"Min drift:                 {min(drifts):+.3f}%")
print(f"Max drift:                 {max(drifts):+.3f}%")

print()
print("===== NORMALIZED RESULTS =====")
print()
print("VAR   N    RAW_MEDIAN_PPS   MEAN_%     MEDIAN_%    SD_%      95% CI              WINS")

for v in ["B", "C", "D", "E", "F"]:
    xs = normalized[v]
    if not xs:
        continue

    mean = st.mean(xs)
    median = st.median(xs)
    sd = st.stdev(xs) if len(xs) > 1 else 0.0
    lo, hi = bootstrap_ci(xs)
    wins = sum(1 for x in xs if x > 0)

    print(f"{v:<4} {len(xs):<4} {st.median(raw[v]):>14.2f}   {mean:>+8.3f}%   {median:>+8.3f}%   {sd:>7.3f}%   [{lo:+.3f}, {hi:+.3f}]   {wins}/{len(xs)}")

print()
print("===== IMPORTANT PAIRED COMPARISONS =====")

comparisons = [("C", "B"), ("E", "B"), ("F", "B"), ("F", "C"), ("F", "E")]

for x, y in comparisons:
    diffs = []

    for r in sorted(per_round):
        if x in per_round[r] and y in per_round[r]:
            diff = 100.0 * (per_round[r][x] / per_round[r][y] - 1.0)
            diffs.append(diff)

    if not diffs:
        continue

    lo, hi = bootstrap_ci(diffs)
    wins = sum(1 for d in diffs if d > 0)

    print(f"{x} vs {y}: mean {st.mean(diffs):+.3f}% | median {st.median(diffs):+.3f}% | 95% CI [{lo:+.3f}, {hi:+.3f}] | wins {wins}/{len(diffs)}")

print()
print("===== ROUND BY ROUND =====")

for r in sorted(per_round):
    values = []
    for v in ["B", "C", "D", "E", "F"]:
        if v in per_round[r]:
            pct = 100.0 * (per_round[r][v] - 1.0)
            values.append(f"{v}={pct:+.2f}%")
    print(f"Round {r:2d}: " + "  ".join(values))
