# Testovi za Petnica nftables optimizer

Ovaj folder sadrži testove koji su stvarno korišćeni na Debian VM-u i rezultate koje sam sačuvao tokom rada.

Glavni benchmark je `tests/bracket-benchmark.sh`. U svakoj od 20 rundi isti baseline A se meri na početku i na kraju, dok se B, C, D, E i F nasumično raspoređuju između njih. Pre svakog merenja se radi 2 x 100k warmup paketa, a zatim 20 x 100k merenih paketa u jednom `tcpreplay --loop` procesu. Analyzer procenjuje lokalni baseline linearnom interpolacijom između A_pre i A_post i svaku unutrašnju varijantu normalizuje prema tom baseline-u.

Varijante su: A = baseline prevedeni nftables; B = baseline + stock `nft --optimize`; C = naš reorder; D = reorder + stock; E = reorder + specialized chainovi; F = specialized + stock.

`tests/native-control-v2.sh` je prethodni A/A kontrolni test. On je pokazao sistematski order/warm-up efekat: drugo identično baseline merenje je bilo konzistentno brže. Zbog toga običan benchmark sa jednim globalnim baseline-om nije bio dovoljno pouzdan i prešlo se na bracket dizajn.

`results/bracket_analysis.txt` sadrži konačni transkript analize sa 20 rundi. Najbitnije poređenje je F vs B: mean +0.863%, median +0.737%, bootstrap 95% CI [+0.438%, +1.283%], wins 16/20. C vs B i E vs B takođe imaju interval iznad nule. F vs C i F vs E nemaju jasan dodatni signal jer njihovi intervali prelaze nulu.

`results/native_control_v2.csv` je prepisan iz terminalskog rezultata sa screenshot-a. `results/normalized_rounds.csv` i `results/bracket_analysis.txt` su prepisani iz finalnog analyzer output-a. Originalni sirovi `bracket_benchmark.csv` ostao je na VM-u i treba ga dodati u repo kada se kopira sa VM-a; ovde ga nisam izmišljao niti rekonstruisao iz normalizovanih rezultata.

Folder `evidence` sadrži screenshotove terminala iz samog testiranja. `docs/beleske_testiranja.docx` je kratka studentska beleška sa objašnjenjem šta je rađeno, zašto je metod menjan i šta trenutni rezultat znači.
