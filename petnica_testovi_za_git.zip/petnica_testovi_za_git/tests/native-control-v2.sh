#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

cd ~/petnica-nft
source ./linux-testbed/common.sh

ROUNDS=12
LOOPS=10
PCAP="$(readlink -f traffic_100k.pcap)"
OUT="native_control_v2.csv"

echo "round,measurement,packets,elapsed_s,pps" > "$OUT"

sudo -v

run_one() {
    round="$1"
    measurement="$2"

    sudo env LC_ALL=C TESTBED_MTU=65535 ./linux-testbed/load-ruleset.sh baseline_forward.nft >/dev/null
    tmp=$(mktemp)
    sudo ip netns exec "$SENDER_NS" tcpreplay --intf1="$SENDER_IF" --topspeed --loop="$LOOPS" "$PCAP" >"$tmp" 2>&1

    packets=$(awk '/^Actual:/ {gsub(/,/, "", $2); print $2; exit}' "$tmp")
    elapsed=$(awk '/^Actual:/ {for (i=1; i<=NF; i++) if ($i=="seconds") {print $(i-1); exit}}' "$tmp")
    pps=$(awk '/^Rated:/ {for (i=1; i<=NF; i++) if ($i=="pps") {gsub(/,/, "", $(i-1)); print $(i-1); exit}}' "$tmp")

    if [[ -z "$packets" || -z "$elapsed" || -z "$pps" ]]; then
        echo "ERROR parsing tcpreplay output"
        cat "$tmp"
        rm -f "$tmp"
        exit 1
    fi

    echo "$round,$measurement,$packets,$elapsed,$pps" | tee -a "$OUT"
    rm -f "$tmp"
}

echo "===== WARMUP ====="
sudo env LC_ALL=C TESTBED_MTU=65535 ./linux-testbed/load-ruleset.sh baseline_forward.nft >/dev/null
sudo ip netns exec "$SENDER_NS" tcpreplay --intf1="$SENDER_IF" --topspeed --loop=3 "$PCAP" >/dev/null 2>&1
sleep 3

echo "===== A/A STABILITY TEST ====="
for r in $(seq 1 "$ROUNDS"); do
    echo "===== ROUND $r / $ROUNDS ====="
    run_one "$r" A1
    run_one "$r" A2
    sleep 2
done

echo "===== DONE ====="
echo "Results: $OUT"
