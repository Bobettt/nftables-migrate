#!/usr/bin/env bash
set -euo pipefail
export LC_ALL=C

cd ~/petnica-nft
source ./linux-testbed/common.sh

ROUNDS=20
WARMUP_LOOPS=2
MEASURE_LOOPS=20
PCAP="$(readlink -f traffic_100k.pcap)"
OUT="bracket_benchmark.csv"

declare -A F
F[A]=baseline_forward.nft
F[B]=baseline_stock.nft
F[C]=reordered_forward.nft
F[D]=reordered_stock.nft
F[E]=specialized_forward_testfix.nft
F[F]=specialized_stock.nft

echo "round,position,variant,packets,elapsed_s,pps" > "$OUT"

sudo -v

run_one() {
    round="$1"
    position="$2"
    variant="$3"
    file="${F[$variant]}"

    sudo env LC_ALL=C TESTBED_MTU=65535 ./linux-testbed/load-ruleset.sh "$file" >/dev/null
    sudo ip netns exec "$SENDER_NS" tcpreplay --intf1="$SENDER_IF" --topspeed --preload-pcap --loop="$WARMUP_LOOPS" "$PCAP" >/dev/null 2>&1

    tmp=$(mktemp)
    sudo ip netns exec "$SENDER_NS" tcpreplay --intf1="$SENDER_IF" --topspeed --preload-pcap --loop="$MEASURE_LOOPS" "$PCAP" >"$tmp" 2>&1

    packets=$(awk '/^Actual:/ {gsub(/,/, "", $2); print $2; exit}' "$tmp")
    elapsed=$(awk '/^Actual:/ {for (i=1; i<=NF; i++) if ($i=="seconds") {print $(i-1); exit}}' "$tmp")
    pps=$(awk '/^Rated:/ {for (i=1; i<=NF; i++) if ($i=="pps") {gsub(/,/, "", $(i-1)); print $(i-1); exit}}' "$tmp")

    if [[ -z "$packets" || -z "$elapsed" || -z "$pps" ]]; then
        echo "ERROR parsing tcpreplay output for $variant"
        cat "$tmp"
        rm -f "$tmp"
        exit 1
    fi

    echo "$round,$position,$variant,$packets,$elapsed,$pps" | tee -a "$OUT"
    rm -f "$tmp"
}

echo "===== BRACKET BENCHMARK ====="

for r in $(seq 1 "$ROUNDS"); do
    echo
    echo "===== ROUND $r / $ROUNDS ====="

    run_one "$r" 0 A
    mapfile -t ORDER < <(printf '%s\n' B C D E F | shuf)

    pos=1
    for v in "${ORDER[@]}"; do
        run_one "$r" "$pos" "$v"
        pos=$((pos + 1))
    done

    run_one "$r" 6 A
    sleep 2
done

echo
echo "===== DONE ====="
echo "Results: $OUT"
